# PygameLOZReskin
Year 12 project

## Character Class Skeleton Code
```py

class Zeb(pygame.sprite.Sprite):
# This class includes functions which allows the player to operate
    
    def __init__(self, #attributes):
    # function to assign values to object properties when the object is being created
        ...
    def walk(self):
    # gets input from the player and uses it to change the direction of the character
        ...
    
    def update(self):
    # function to update the game state and projecting it in real-time. AKA moving the character, stabbing the baddies
        ...
        
```
